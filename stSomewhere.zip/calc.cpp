#include <iostream>
#include <cmath>
#include <bitset>
#include <string>
#include <algorithm>
#include <cstdlib>
#include "calc.h"

using namespace std;

/*
  I found this on the interwebs after itoa failed to work. It's so elegant I had to include it :)
  C++ version 0.4 std::string style "itoa":
  Contributions from Stuart Lowe, Ray-Yuan Sheu,
  Rodrigo de Salvo Braz, Luc Gallant, John Maloney
  and Brian Hunt
*/
string Calc::itoa(int value, int base)
{

  string buf;

  //check that the base if valid
  if (base < 2 || base > 16) return buf;

  //Pre-allocate enough space
  enum { kMaxDigits = 44 };
  buf.reserve( kMaxDigits );

  int quotient = value;
  // Translating number to string with base:
  do
  {
    buf += "0123456789ABCDEF"[ abs( quotient % base ) ];
    quotient /= base;
  } while ( quotient );
  // Append the negative sign
  if ( value < 0) buf += '-';
  reverse( buf.begin(), buf.end() );
  return buf;
}

/*
  Accepts a string, assumed to have only one's and zero's, and adds them together.
*/
int Calc::convertBD(string binary)
{
  int length = binary.length(), sum(0);
  for (int i=0; i<length; i++)
  {
    //This setup assumes any non zero is supposed to be 1
    if (binary[i] == '0')
      ;
    else
      sum += pow(2, length-i-1);
  }
  return sum;
}

/*
  Accepts a hex string, converts to decimal, and then returns the decimal value.
*/
int Calc::convertHD(string stringValue)
{
  int length = stringValue.length(), sum=0;
  for (int i=0; i<length; i++)
  {
    switch(stringValue[i])
    {
      case '0':
        break;
      case '1':
        sum += pow(16, length-i-1);
        break;
      case '2':
        sum += 2*pow(16, length-i-1);
        break;
      case '3':
        sum += 3*pow(16, length-i-1);
        break;
      case '4':
        sum += 4*pow(16, length-i-1);
        break;
      case '5':
        sum += 5*pow(16, length-i-1);
        break;
      case '6':
        sum += 6*pow(16, length-i-1);
        break;
      case '7':
        sum += 7*pow(16, length-i-1);
        break;
      case '8':
        sum += 8*pow(16, length-i-1);
        break;
      case '9':
        sum += 9*pow(16, length-i-1);
        break;
      case 'a':
      case 'A':
        sum += 10*pow(16, length-i-1);
        break;
      case 'b':
      case 'B':
        sum += 11*pow(16, length-i-1);
        break;
      case 'c':
      case 'C':
        sum += 12*pow(16, length-i-1);
        break;
      case 'd':
      case 'D':
        sum += 13*pow(16, length-i-1);
        break;
      case 'e':
      case 'E':
        sum += 14*pow(16, length-i-1);
        break;
      case 'f':
      case 'F':
        sum += 15*pow(16, length-i-1);
        break;
      default:
        cerr << "Error in DHex switch";
    }
  }
  return sum;
}


int Calc::convertOD(string stringValue)
{
  int length = stringValue.length(), sum=0;
  for (int i=0; i<length; i++)
  {
    switch(stringValue[i])
    {
      case '0':
        break;
      case '1':
        sum += pow(8, length-i-1);
        break;
      case '2':
        sum += 2*pow(8, length-i-1);
        break;
      case '3':
        sum += 3*pow(8, length-i-1);
        break;
      case '4':
        sum += 4*pow(8, length-i-1);
        break;
      case '5':
        sum += 5*pow(8, length-i-1);
        break;
      case '6':
        sum += 6*pow(8, length-i-1);
        break;
      case '7':
        sum += 7*pow(8, length-i-1);
        break;
      default:
        cerr << "Error in convertOD switch";
    }
  }
  return sum;
}

void Calc::initialize()
{
  for (int i=0; i<4; i++)
  {
    value[i] = 0;
    display[i] = "";
  }
}

void Calc::add()
{
  //add the bottom two values in the stack
  value[0] += value[1];
  display[0] = itoa(value[0], base);
  //move the stack down
  for (int i=1; i<3; i++)
  {
    value[i] = value[i+1];
    display[i] = display[i+1];
  }
  value[3] = 0;
  display[3] = "";
}

void Calc::subtract()
{
  //subtract the bottom number from the one above it
  value[0] = value[1] - value[0];
  display[0] = itoa(value[0], base);
  //move the stack down
  for (int i=1; i<3; i++)
  {
    value[i] = value[i+1];
    display[i] = display[i+1];
  }
  value[3] = 0;
  display[3] = "";
}


void Calc::mult()
{
  //multiply the bottom two numbers in the stack
  value[0] *= value[1];
  display[0] = itoa(value[0], base);
  //move the stack down
  for (int i=1; i<3; i++)
  {
    value[i] = value[i+1];
    display[i] = display[i+1];
  }
  value[3] = 0;
  display[3] = "";
}

void Calc::div()
{
  //Divide the bottom number into the one aboce it(gives quotient)
  value[0] = value[1]/value[0];
  display[0] = itoa(value[0], base);
  //move the stack down
  for (int i=1; i<3; i++)
  {
    value[i] = value[i+1];
    display[i] = display[i+1];
  }
  value[3] = 0;
  display[3] = "";
}

void Calc::mod()
{
  //Finds the remainder of the bottom number divided into the one above
  value[0] = value[1]%value[0];
  display[0] = itoa(value[0], base);
  //move the stack down
  for (int i=1; i<3; i++)
  {
    value[i] = value[i+1];
    display[i] = display[i+1];
  }
  value[3] = 0;
  display[3] = "";
}

void Calc::setInputValue(string input)
{
  //move the values in the stack up one to prepare for new input
  for (int i=3; i>0; i--)
  {
    value[i] = value[i-1];
    display[i] = display[i-1];
  }

  switch (getBase())
  {
    case 10:
      {
        value[0] = atoi(input.c_str());
        display[0] = itoa(value[0], 10);
      }
      break;
    case 2:
      value[0] = convertBD(input);
      display[0] = input;
      break;
    case 8:
      value[0] = convertOD(input);
      display[0] = input;
      break;
    case 16:
      value[0] = convertHD(input);
      display[0] = input;
      break;
    default:
      cerr << "Error in setValue switch";
  }
}

char Calc::getBase()
{
  return base;
}

void Calc::setBase(char bse)
{
  if (bse=='d' || bse=='o' || bse=='h' || bse=='b')
  {
    switch (bse)
    {
      case 'd':
        base = 10;
        break;
      case 'b':
        base = 2;
        break;
      case 'h':
        base = 16;
        break;
      case 'o':
        base = 8;
        break;
      default:
        cerr << "Error in base assignment switch";
    }
  }
  else
    cerr << "invalid selection";
}

string Calc::getDisplay(int pos)
{
  return display[pos];
}

bool Calc::inputCheck(string input)
{
    if (input.length()>9)
      return false;

    switch (base)
    {
      case 10:
        for (int i=0; i<input.length(); i++)
        {
          if (!isdigit(input[i]))
            return false;
        }
        break;
      case 2:
        for (int i=0; i<input.length(); i++)
        {
          if (input[i] == '0' || input[i] == '1')
            return true;
          else
            return false;
        }
        break;
      case 8:
        for (int i=0; i<input.length(); i++)
        {
          if (input[i] == '8' || input[i] == '9' || !isdigit(input[i]))
            return false;
        }
        break;
      case 16:
        for (int i=0; i<input.length(); i++)
        {
          if (input[i] == 'A' || input[i] == 'B' || input[i] == 'C' || input[i] == 'D' || input[i] == 'E'
             || input[i] == 'F' || isdigit(input[i]))
              return true;
          else
            return false;
        }
        break;
      default:
        cerr << "Error in inputCheck switch";
    }
    return true;
}


