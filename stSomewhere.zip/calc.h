#ifndef CALC_H
#define CALC_H
#include <string>
#include <bitset>

using namespace std;

const int BITS = 48;

class Calc
{
  private:
    int base;
    string display[4];
    int value[4];

    string itoa(int, int);
    int convertBD(string);
    int convertHD(string);
    int convertOD(string);
  public:
    void initialize();
    bool inputCheck(string);
    void setInputValue(string);
    int getValue(int);
    void setBase(char);
    char getBase();
    string getDisplay(int);
    void add();
    void subtract();
    void mult();
    void div();
    void mod();
};

#endif
